#!/bin/bash

python emulator.py mygostname D:/python/dz1/archive.zip D:/python/dz1/start_script.txt