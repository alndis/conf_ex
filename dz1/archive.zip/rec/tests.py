import unittest
import os
from vfs import VFS  # импортируем класс VFS из файла vfs.py

class TestVFS(unittest.TestCase):
    def setUp(self):
        self.vfs = VFS('/')

    def test_cd_absolute_path(self):
        self.vfs.change_directory('/test')
        self.assertEqual(self.vfs.current_path, '/test')

    def test_cd_relative_path(self):
        self.vfs.change_directory('/test')
        self.vfs.change_directory('subdir')
        self.assertEqual(self.vfs.current_path, '/test/subdir')

    def test_cd_parent_directory(self):
        self.vfs.change_directory('/test')
        self.vfs.change_directory('..')
        self.assertEqual(self.vfs.current_path, '/')

    def test_cd_invalid_path(self):
        self.vfs.change_directory('/invalid/path')
        self.assertEqual(self.vfs.current_path, '/')

    def test_log_file(self):
        self.vfs.change_directory('/test')
        self.assertTrue(os.path.exists('vfs_log.csv'))

    def test_log_file_contents(self):
        self.vfs.change_directory('/test')
        with open('vfs_log.csv', 'r') as csvfile:
            log_reader = csv.reader(csvfile)
            self.assertEqual(next(log_reader), ['cd /test', '/test'])

if __name__ == '__main__':
    unittest.main()