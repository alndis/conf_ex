import configparser
import zipfile
import os
import csv
import subprocess

class VirtualFS:
    def __init__(self, zip_file):
        self.zip_file = zip_file
        self.fs = {}

    def load_fs(self):
        with zipfile.ZipFile(self.zip_file) as zip:
            for file in zip.namelist():
                self.fs[file] = zip.read(file)

    def get_file(self, path):
        return self.fs.get(path)

    def list_dir(self, path):
        return [file for file in self.fs if file.startswith(path + "/")]

def parse_config(config_file):
    config = configparser.ConfigParser()
    config.read(config_file)
    try:
        vfs_archive = config["vfs"]["archive"]
    except KeyError:
        print("Error: 'vfs' section not found in configuration file")
        vfs_archive = None
    return vfs_archive

def ls(vfs, path):
    return vfs.list_dir(path)

def cd(vfs, path):
    if path in vfs.fs:
        return path
    else:
        return "Error: Directory not found"

def exit():
    return "Exiting emulator"

def uname():
    return "Emulator OS"

def rmdir(vfs, path):
    if path in vfs.fs:
        del vfs.fs[path]
        return "Directory deleted"
    else:
        return "Error: Directory not found"

def execute_startup_script(script_file):
    with open(script_file) as f:
        commands = [line.strip() for line in f.readlines()]
    for command in commands:
        subprocess.run(command, shell=True)

def log_action(log_file, action):
    with open(log_file, 'a', newline='') as f:
        writer = csv.writer(f)
        writer.writerow([action])

def main():
    config_file = "config.ini"
    config = parse_config(config_file)
    vfs_archive = parse_config(config_file)
    if vfs_archive is None:
        print("Error: Unable to load emulator")
        return
    vfs = VirtualFS(vfs_archive)
    vfs.load_fs()
    print(type(config))
    print(config)
    log_file = config["log"]["file"]
    startup_script = config["startup"]["script"]

    while True:
        command = input("> ")
        if command == "exit":
            print(exit())
            break
        elif command.startswith("cd "):
            print(cd(vfs, command[3:]))
        elif command.startswith("ls "):
            print(ls(vfs, command[3:]))
        elif command == "uname":
            print(uname())
        elif command.startswith("rmdir "):
            print(rmdir(vfs, command[6:]))
        else:
            print("Error: Unknown command")

if __name__ == "__main__":
    main()