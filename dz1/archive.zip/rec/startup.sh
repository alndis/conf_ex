#!/bin/bash

# Start the emulator script
python emulator.py